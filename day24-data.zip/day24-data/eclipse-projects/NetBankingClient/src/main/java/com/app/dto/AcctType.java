package com.app.dto;

public enum AcctType {
	SAVING, CURRENT, FD, LOAN
}
