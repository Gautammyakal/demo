import React, { Component } from 'react';

export default class FirstComp extends Component {
  render() {
    return (
      <div className='FirstComponent'>
        <h3>First Component</h3>
      </div>
    );
  }
}
export class TestComp extends Component {
  render() {
    return (
      <div>
        <h3>Test Component</h3>
      </div>
    );
  }
}
